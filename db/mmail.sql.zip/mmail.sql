-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 01, 2017 at 05:53 PM
-- Server version: 5.7.19-0ubuntu0.16.04.1
-- PHP Version: 7.0.22-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mmail`
--

-- --------------------------------------------------------

--
-- Table structure for table `application_logs`
--

CREATE TABLE `application_logs` (
  `id` int(11) NOT NULL,
  `account_id` bigint(20) UNSIGNED DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `section` varchar(255) CHARACTER SET utf16 NOT NULL,
  `action` varchar(255) CHARACTER SET utf16 NOT NULL,
  `item` int(11) NOT NULL,
  `action_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `changed` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `application_logs`
--

INSERT INTO `application_logs` (`id`, `account_id`, `user_id`, `section`, `action`, `item`, `action_time`, `changed`) VALUES
(1, NULL, 1, 'Subscriber', 'update', 1, '2017-08-31 13:16:16', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `data_categories`
--

CREATE TABLE `data_categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `data_categories`
--

INSERT INTO `data_categories` (`id`, `user_id`, `name`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 'Ahmedabad', 1, '2017-08-31 12:29:48', '2017-08-31 12:29:48'),
(2, 1, 'Cygnet', 1, '2017-08-31 13:07:57', '2017-08-31 13:07:57'),
(3, 1, 'CG Road', 1, '2017-08-31 13:16:47', '2017-08-31 13:16:47'),
(4, 1, 'Temp', 1, '2017-08-31 13:45:09', '2017-08-31 13:45:09');

-- --------------------------------------------------------

--
-- Table structure for table `data_mailers`
--

CREATE TABLE `data_mailers` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `subscriber_id` int(11) NOT NULL,
  `template_id` int(11) NOT NULL,
  `send_status` tinyint(4) NOT NULL DEFAULT '0',
  `schedule_time` datetime NOT NULL,
  `send_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `data_mailers`
--

INSERT INTO `data_mailers` (`id`, `user_id`, `subscriber_id`, `template_id`, `send_status`, `schedule_time`, `send_at`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 2, 1, '2017-08-31 18:01:37', '2017-08-31 18:35:43', NULL, '2017-08-31 13:05:43'),
(2, 1, 1, 3, 1, '2017-08-31 18:39:46', '2017-08-31 18:40:06', NULL, '2017-08-31 13:10:06'),
(3, 1, 2, 3, 1, '2017-08-31 18:39:46', '2017-08-31 18:40:06', NULL, '2017-08-31 13:10:06'),
(4, 1, 1, 4, 1, '2017-08-31 18:47:25', '2017-08-31 18:47:48', NULL, '2017-08-31 13:17:48'),
(5, 1, 2, 4, 1, '2017-08-31 18:47:25', '2017-08-31 18:47:48', NULL, '2017-08-31 13:17:48'),
(6, 1, 3, 4, 1, '2017-08-31 18:47:25', '2017-08-31 18:47:48', NULL, '2017-08-31 13:17:48'),
(7, 1, 1, 5, 1, '2017-08-31 18:52:27', '2017-08-31 18:53:17', NULL, '2017-08-31 13:23:17'),
(8, 1, 2, 5, 1, '2017-08-31 18:52:27', '2017-08-31 18:53:17', NULL, '2017-08-31 13:23:17'),
(9, 1, 3, 5, 1, '2017-08-31 18:52:27', '2017-08-31 18:53:17', NULL, '2017-08-31 13:23:17'),
(10, 1, 1, 6, 1, '2017-09-01 17:35:53', '2017-09-01 17:36:14', NULL, '2017-09-01 12:06:14'),
(11, 1, 2, 6, 1, '2017-09-01 17:35:53', '2017-09-01 17:36:14', NULL, '2017-09-01 12:06:14'),
(12, 1, 3, 6, 1, '2017-09-01 17:35:53', '2017-09-01 17:36:14', NULL, '2017-09-01 12:06:14'),
(13, 1, 1, 7, 0, '2017-09-01 17:39:51', NULL, NULL, NULL),
(14, 1, 3, 7, 0, '2017-09-01 17:39:51', NULL, NULL, NULL),
(15, 1, 1, 8, 0, '2017-09-01 17:43:53', NULL, NULL, NULL),
(16, 1, 2, 8, 0, '2017-09-01 17:43:53', NULL, NULL, NULL),
(17, 1, 3, 8, 0, '2017-09-01 17:43:53', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `data_mailers_log`
--

CREATE TABLE `data_mailers_log` (
  `id` int(10) UNSIGNED NOT NULL,
  `subscriber_id` int(11) NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `data_mailers_log`
--

INSERT INTO `data_mailers_log` (`id`, `subscriber_id`, `subject`, `body`, `created_at`, `updated_at`) VALUES
(1, 1, 'Hey - first email', 'this is First email FromUser', NULL, NULL),
(2, 1, 'Second mail Testing', 'Hello Guys,\r\n\r\nThis is second email Testing.', NULL, NULL),
(3, 2, 'Second mail Testing', 'Hello Guys,\r\n\r\nThis is second email Testing.', NULL, NULL),
(4, 1, 'Hey Guy', 'Helllo Boys,\r\n\r\nHope you doing well !', NULL, NULL),
(5, 2, 'Hey Guy', 'Helllo Boys,\r\n\r\nHope you doing well !', NULL, NULL),
(6, 3, 'Hey Guy', 'Helllo Boys,\r\n\r\nHope you doing well !', NULL, NULL),
(7, 1, 'CRON Test', 'Hey Guys,\r\n\r\nTesting from CRON Tab.', NULL, NULL),
(8, 2, 'CRON Test', 'Hey Guys,\r\n\r\nTesting from CRON Tab.', NULL, NULL),
(9, 3, 'CRON Test', 'Hey Guys,\r\n\r\nTesting from CRON Tab.', NULL, NULL),
(10, 1, 'sadf', 'asdf', NULL, NULL),
(11, 2, 'sadf', 'asdf', NULL, NULL),
(12, 3, 'sadf', 'asdf', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `data_sms`
--

CREATE TABLE `data_sms` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `subscriber_id` int(11) NOT NULL,
  `message` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `send_status` int(11) NOT NULL DEFAULT '0',
  `schedule_time` datetime DEFAULT NULL,
  `send_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `data_sms`
--

INSERT INTO `data_sms` (`id`, `user_id`, `subscriber_id`, `message`, `status`, `send_status`, `schedule_time`, `send_at`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'Send To All', 0, 0, '2017-09-01 17:52:02', NULL, NULL, NULL),
(2, 1, 2, 'Send To All', 0, 0, '2017-09-01 17:52:02', NULL, NULL, NULL),
(3, 1, 3, 'Send To All', 0, 0, '2017-09-01 17:52:02', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `data_sms1`
--

CREATE TABLE `data_sms1` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `subscriber_id` int(11) NOT NULL,
  `message` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `send_status` int(11) NOT NULL DEFAULT '0',
  `schedule_time` datetime NOT NULL,
  `send_at` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `data_sms1`
--

INSERT INTO `data_sms1` (`id`, `user_id`, `subscriber_id`, `message`, `status`, `send_status`, `schedule_time`, `send_at`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'Test', 0, 0, '2017-09-01 13:27:36', '2017-09-01 13:27:36', '2017-09-01 07:57:36', '2017-09-01 07:57:36');

-- --------------------------------------------------------

--
-- Table structure for table `data_subscribers`
--

CREATE TABLE `data_subscribers` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `company_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other_contact` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other_email_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `designation` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `data_subscribers`
--

INSERT INTO `data_subscribers` (`id`, `user_id`, `category_id`, `company_name`, `name`, `mobile`, `other_contact`, `email_id`, `other_email_id`, `gender`, `birth_date`, `designation`, `notes`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'Test Comp', 'User 1', '1246578', '65656', 'cygnet.ayjaha@gmail.com', NULL, NULL, NULL, NULL, 'This is sample', 1, '2017-08-31 12:30:15', '2017-08-31 13:16:16'),
(2, 1, 2, 'Tset', 'Out of Station', '13214567', '15987', 'ayjaha@cygnet-infotech.com', NULL, NULL, NULL, NULL, 'test', 1, '2017-08-31 13:09:01', '2017-08-31 13:09:01'),
(3, 1, 3, 'C G Road', 'C G Road', '12345679', '6565565', 'er.anujjaha@gmail.com', NULL, NULL, NULL, NULL, 'This is Tset', 1, '2017-08-31 13:17:09', '2017-08-31 13:17:09');

-- --------------------------------------------------------

--
-- Table structure for table `data_templates`
--

CREATE TABLE `data_templates` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `data_templates`
--

INSERT INTO `data_templates` (`id`, `user_id`, `subject`, `body`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 'Test - Campaign', 'This is Sample', 1, '2017-08-31 12:30:32', '2017-08-31 12:30:32'),
(2, 1, 'Hey - first email', 'this is First email FromUser', 1, '2017-08-31 12:31:37', '2017-08-31 12:31:37'),
(3, 1, 'Second mail Testing', 'Hello Guys,\r\n\r\nThis is second email Testing.', 1, '2017-08-31 13:09:46', '2017-08-31 13:09:46'),
(4, 1, 'Hey Guy', 'Helllo Boys,\r\n\r\nHope you doing well !', 1, '2017-08-31 13:17:25', '2017-08-31 13:17:25'),
(5, 1, 'CRON Test', 'Hey Guys,\r\n\r\nTesting from CRON Tab.', 1, '2017-08-31 13:22:27', '2017-08-31 13:22:27'),
(6, 1, 'sadf', 'asdf', 1, '2017-09-01 12:05:53', '2017-09-01 12:05:53'),
(7, 1, 'Rock  Test With SMS', 'Hello test', 1, '2017-09-01 12:09:51', '2017-09-01 12:09:51'),
(8, 1, 'Roick', 'this anothe rte', 1, '2017-09-01 12:13:53', '2017-09-01 12:13:53');

-- --------------------------------------------------------

--
-- Table structure for table `data_update_logs`
--

CREATE TABLE `data_update_logs` (
  `id` bigint(20) NOT NULL,
  `account_id` bigint(20) UNSIGNED DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `section` varchar(255) CHARACTER SET utf16 NOT NULL,
  `action` varchar(255) CHARACTER SET utf16 NOT NULL,
  `item` int(11) NOT NULL,
  `action_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `changed` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `id` int(10) UNSIGNED NOT NULL,
  `type_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `entity_id` int(10) UNSIGNED DEFAULT NULL,
  `icon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `class` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `assets` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `history_types`
--

CREATE TABLE `history_types` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `history_types`
--

INSERT INTO `history_types` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'User', '2017-08-24 08:39:58', '2017-08-24 08:39:58'),
(2, 'Role', '2017-08-24 08:39:58', '2017-08-24 08:39:58');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2015_12_28_171741_create_social_logins_table', 1),
(4, '2015_12_29_015055_setup_access_tables', 1),
(5, '2016_07_03_062439_create_history_tables', 1),
(6, '2017_04_04_131153_create_sessions_table', 1),
(7, '2017_07_05_131517_create_table_for_categories', 1),
(8, '2017_07_06_133815_create_table_subscribers', 1),
(9, '2017_07_13_131711_create_new_table_data_templates', 1),
(10, '2017_07_14_073740_create_new_table_data_mailers', 1),
(11, '2017_07_17_180426_create_jobs_table', 1),
(12, '2017_07_17_184408_create_new_table_data_mailers_log', 1),
(14, '2017_09_01_163024_create_data_sms_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `display_name`, `sort`, `created_at`, `updated_at`) VALUES
(1, 'view-backend', 'View Backend', 1, '2017-08-24 08:39:57', '2017-08-24 08:39:57');

-- --------------------------------------------------------

--
-- Table structure for table `permission_role`
--

CREATE TABLE `permission_role` (
  `id` int(10) UNSIGNED NOT NULL,
  `permission_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permission_role`
--

INSERT INTO `permission_role` (`id`, `permission_id`, `role_id`) VALUES
(1, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `all` tinyint(1) NOT NULL DEFAULT '0',
  `sort` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `all`, `sort`, `created_at`, `updated_at`) VALUES
(1, 'Administrator', 1, 1, '2017-08-24 08:39:55', '2017-08-24 08:39:55'),
(2, 'Executive', 0, 2, '2017-08-24 08:39:55', '2017-08-24 08:39:55'),
(3, 'User', 0, 3, '2017-08-24 08:39:55', '2017-08-24 08:39:55');

-- --------------------------------------------------------

--
-- Table structure for table `role_user`
--

CREATE TABLE `role_user` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_user`
--

INSERT INTO `role_user` (`id`, `user_id`, `role_id`) VALUES
(1, 1, 1),
(2, 2, 2),
(3, 3, 3);

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('SRZYBowvuym0VrLUvrXbDEkn4N44VHTIAYXZ1LXT', 1, '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'ZXlKcGRpSTZJbVpEUTNGS1NrcFZkRTFHUmxWa2NGTjNTRFZqYm1jOVBTSXNJblpoYkhWbElqb2lRVmt5U0V4b04yMVpLM00yVjFsWk1tcDRVMlpTYTNSaE0yOXBZMWd6UTBWdGRWaGlRa3hYWmtWSGVISk1jMlpuWEM5SFVtbHFYQzlVWTBaSWNVbG1XWFJSUlVZeE1GRXJLMUUwTjNwMVVGUlJWVXByUTFscFlVOXRXbTFJV0RoNlNrdDRRMDF3UlRsNFQyTTJkRUZRZDJaWGNGZ3hjM2hIY0VwMVVIZEpjRTlvZGtOTVZrWm5kazR6TjNSRWJHWTJUMHRhY0VKcWJGVnlVRXgwUkdJMmIwUklaMGRuYlZkVUswaEhaMVJGTmpKUWFUTnVlbEpGYUVsSE4wVnZWMnBJZDBadldFOUtPVlpoVFZGcmNHNWNMMHBUTkhrMlpUZFNLM0ppZUZKbU5FeG5ZVVZ4VUZOM0swOHdUM0l3ZHpKdmMwZGNMMGhYVVRZMGJVSm9kV3haYjFsNFdHSTViazVvSzBKM1dsd3ZRV0ZPVXpWRFVUZGFkWEYxTTBSMFUzVkdRMjh6UXpKSlFWTlpkVTFaU3pGV1ZreEhWR3BhWm1wSmVGTmFXRFJvV0hOV2VubEZVMGxNUW1VNE1pc3hkRE01V2pkeFZsQnFVV0ZNTVV3MllXWnBjVTV5T0hGSE9Ib3pibmw0Y1V0dmFFVlhTRTV4WldaSVZ5dEROWEZOTjBoS1R6RkJVSGx2VURBcldHcFRRMDFFVFhoRldUaFBXbnBpYmt3clJVOUNVMnhrUVhaTWIzWTJiSGxQTmxac0sweHFhVWhGTTF3dlNqUXlZVkYyTmxwcmFEVlBTa2hDY0NJc0ltMWhZeUk2SWpNM056Z3dabVZqTkRjNE1USmtaV1psTWpnNU5tSmtaVEE1Tm1RNU1UWm1NRFZqTWpBME1UTXdaRFV4WmpVM1pUTTBOR00xWmpBellXTmpNRGN3WldZaWZRPT0=', 1504268558);

-- --------------------------------------------------------

--
-- Table structure for table `social_logins`
--

CREATE TABLE `social_logins` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `provider` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(3) UNSIGNED NOT NULL DEFAULT '1',
  `confirmation_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `confirmed` tinyint(1) NOT NULL DEFAULT '0',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `status`, `confirmation_code`, `confirmed`, `remember_token`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Admin Istrator', 'admin@admin.com', '$2y$10$UGm8ZOIhQArCtcZDJMwujuBJJlOixg4H/p2XSPotZXfxx06OoQUcO', 1, '13703335dc4dbcdd3571e4dc9228cc68', 1, 'uInZWLGwwja30GRUefm3JEAVFQ0zbjZB0WgwkKTdIBWq7JCYKduwWBWRLjhh', '2017-08-24 08:39:55', '2017-08-24 08:39:55', NULL),
(2, 'Backend User', 'executive@executive.com', '$2y$10$NW0TnrHQk8UVGJUZYkWU3OUCn.iXrc.KoBi/y6WH2maqXV3/Axo5S', 1, '30d698a065323f1ef6cbe74c3888b815', 1, NULL, '2017-08-24 08:39:55', '2017-08-24 08:39:55', NULL),
(3, 'Default User', 'user@user.com', '$2y$10$TkPbTJor1EH7h7nIO5QTHOVqo8ySamT3RsPoOe5FiH5aB8yXLynqa', 1, '5d91fa0c570d301be820249fb734b89a', 1, NULL, '2017-08-24 08:39:55', '2017-08-24 08:39:55', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `application_logs`
--
ALTER TABLE `application_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data_categories`
--
ALTER TABLE `data_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data_mailers`
--
ALTER TABLE `data_mailers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data_mailers_log`
--
ALTER TABLE `data_mailers_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data_sms`
--
ALTER TABLE `data_sms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data_sms1`
--
ALTER TABLE `data_sms1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data_subscribers`
--
ALTER TABLE `data_subscribers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data_templates`
--
ALTER TABLE `data_templates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data_update_logs`
--
ALTER TABLE `data_update_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `data_update_logs_account_id_foreign` (`account_id`);

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `history_type_id_foreign` (`type_id`),
  ADD KEY `history_user_id_foreign` (`user_id`);

--
-- Indexes for table `history_types`
--
ALTER TABLE `history_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_reserved_at_index` (`queue`,`reserved_at`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_unique` (`name`);

--
-- Indexes for table `permission_role`
--
ALTER TABLE `permission_role`
  ADD PRIMARY KEY (`id`),
  ADD KEY `permission_role_permission_id_foreign` (`permission_id`),
  ADD KEY `permission_role_role_id_foreign` (`role_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_unique` (`name`);

--
-- Indexes for table `role_user`
--
ALTER TABLE `role_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `role_user_user_id_foreign` (`user_id`),
  ADD KEY `role_user_role_id_foreign` (`role_id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD UNIQUE KEY `sessions_id_unique` (`id`);

--
-- Indexes for table `social_logins`
--
ALTER TABLE `social_logins`
  ADD PRIMARY KEY (`id`),
  ADD KEY `social_logins_user_id_foreign` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `application_logs`
--
ALTER TABLE `application_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `data_categories`
--
ALTER TABLE `data_categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `data_mailers`
--
ALTER TABLE `data_mailers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `data_mailers_log`
--
ALTER TABLE `data_mailers_log`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `data_sms`
--
ALTER TABLE `data_sms`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `data_sms1`
--
ALTER TABLE `data_sms1`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `data_subscribers`
--
ALTER TABLE `data_subscribers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `data_templates`
--
ALTER TABLE `data_templates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `data_update_logs`
--
ALTER TABLE `data_update_logs`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `history`
--
ALTER TABLE `history`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `history_types`
--
ALTER TABLE `history_types`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `permission_role`
--
ALTER TABLE `permission_role`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `role_user`
--
ALTER TABLE `role_user`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `social_logins`
--
ALTER TABLE `social_logins`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `history`
--
ALTER TABLE `history`
  ADD CONSTRAINT `history_type_id_foreign` FOREIGN KEY (`type_id`) REFERENCES `history_types` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `history_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `permission_role`
--
ALTER TABLE `permission_role`
  ADD CONSTRAINT `permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_user`
--
ALTER TABLE `role_user`
  ADD CONSTRAINT `role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `social_logins`
--
ALTER TABLE `social_logins`
  ADD CONSTRAINT `social_logins_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
